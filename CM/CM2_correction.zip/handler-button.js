// 1. Reprendre [l'exemple](CM2_exemples/handler-button.html) pour qu'il déclenche une alarme qui au bout du nombre de secondes saisi dans `input1` ajoute la valeur en cours à `output1`.
// 2. Ajouter un bouton qui déclenchera _n_ alarmes se déclenchant au bout de 1, 2, ... _n_ secondes pour afficher un décompte _n_, ..., 2, 1.
// 3. Même chose que précédent mais en utilisant **uniquement** des alarmes de 1s. La première déclenche la seconde, qui déclenche la suivante etc.
// 4. Même question que 1. mais en affichant _la valeur lors du déclenchement_, pas celle en cours dans l'_input_.

// idée extension :
// - compteur global/local du nombre de décompte généré
// - chaque compteur affiche le temps passé depuis la création, Date.now()

const $output = document.getElementById("output");
const $input = document.getElementById("input");
const $trigger = document.getElementById("trigger");
const $countdown1 = document.getElementById("countdown-1");
const $countdown2 = document.getElementById("countdown-2");
const $countdown3 = document.getElementById("countdown-3");

function addOutput(type, start, msg = "Done!") {
  $output.innerHTML += `(${type}) ${msg} @ (${Date.now() - start}ms) <br/>`;
}

function trigger() {
  setTimeout(() => {
    $output.innerHTML += "done <br/>";
  }, $input.value);
}
$trigger.addEventListener("click", trigger);

function countdown1() {
  const start = Date.now();
  const nbAlarms = Number($input.value);
  for (let i = 0; i < nbAlarms; ++i) {
    setTimeout(() => addOutput("for", start, nbAlarms - i), i * 1000);
  }
  setTimeout(() => addOutput("for", start), nbAlarms * 1000);
}
$countdown1.addEventListener("click", countdown1);

function countdown2() {
  const start = Date.now();
  let nbAlarms = Number($input.value);
  addOutput("setInterval", start, nbAlarms--);
  const alarmId = setInterval(() => {
    if (nbAlarms > 0) {
      addOutput("setInterval", start, nbAlarms--);
    } else {
      addOutput("setInterval", start);
      clearInterval(alarmId);
    }
  }, 1000);
}
$countdown3.addEventListener("click", countdown2);

function delayRecursive(start, nb) {
  if (nb > 0) {
    setTimeout(() => {
      addOutput("rec", start, nb);
      delayRecursive(start, nb - 1);
    }, 1000);
  } else {
    setTimeout(() => addOutput("rec", start), 1000);
  }
}

function countdown3() {
  const nb = Number($input.value);
  const start = Date.now();
  addOutput("rec", start, nb);
  delayRecursive(start, nb - 1);
}
$countdown2.addEventListener("click", countdown3);

