const arr = [
  { name: "Alice", age: 40, sal: 250000 },
  { name: "Bob", age: 17, sal: -1 },
  { name: "Charlie", age: 30, sal: 180000 },
  { name: "Denise", age: 12, sal: -1 },
];

function exo1(arr) {
    return arr.filter((o) => o.age >= 18).map((o) => o.sal).every((s) => s >= 150000);
  }

function exo2(arr) {
  return arr.filter((o) => o.age >= 18).map((o) => `${o.name}: ${o.age}`);
}

function exo3(arr) {
  const red = ({ s, c }, x) => ({ s: x + s, c: c + 1 });
  const r = arr
    .filter((o) => o.age >= 18)
    .map((o) => o.sal)
    .reduce(red, { s: 0, c: 0 });
  return r.s / r.c;
}

console.log(exo1(arr));
console.log(exo2(arr));
console.log(exo3(arr));
