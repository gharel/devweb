/* eslint-disable no-unused-vars */
// Solution de base
function memoizeMonadic(f) {
  const results = {};
  return function (x) {
    if (!results.hasOwnProperty(x)) {
      results[x] = f(x);
    }
    return results[x];
  };
}

// La difficulté pour le codage variadique ici est que les clés de dictionnaire sont des chaînes de caractères.
// Les tableaux sont ainsi convertis automatiquement en {string}.
// Une possibilité consiste à encoder les paramètres avec {JSON.stringify}:
function memoizeVariadic(f) {
  const results = {};
  return function (...x) {
    // necessaire pour les args multiples
    const k = JSON.stringify(x);
    if (!results.hasOwnProperty(k)) {
      results[k] = f(...x);
    }
    return results[k];
  };
}

function memoizeVariadicMap(f) {
  const results = new Map();
  return function (...x) {
    const k = JSON.stringify(x);
    if (!results.has(k)) {
      results.set(k, f(...x));
    }
    return results.get(k);
  };
}

function power(exp, base = 2) {
  console.debug(`power(${exp}, ${base})`);
  return base ** exp;
}

function main() {
  const f1 = memoizeMonadic(power);
  const f2 = memoizeVariadic(power);
  const f3 = memoizeVariadicMap(power);

  console.log(f1(8)); // call : 256
  console.log(f1(8)); // no call : 256
  console.log(f1(3)); // call : 8

  console.log(f2(8, 3)); // call : 6561
  console.log(f2(8, 3)); // no call : 6561
  console.log(f2(3, 3)); // call : 27

  console.log(f3(8, 3)); // call : 6561
  console.log(f3(8, 3)); // no call : 6561
  console.log(f3(3, 3)); // call : 27
}

main();
