/* eslint-disable no-unused-vars */
// solution de base récursive
function chainRecursive(n) {
  return function(f) {
    return function(x) {
      if (n <= 0)
        return x;
      else{
        return chain(n-1)(f)(f(x));
        // ou
        // return f(chain(n-1)(f)(x));
      }
    }
  }
}

chainFoldR = (n) => (f) => (x) => (n <= 0)?(x):f(chain(n-1)(f)(x));
//ou
chainFoldL = (n) => (f) => (x) => (n <= 0)?(x):(chain(n-1)(f)(f(x)));

// solution itérative
function chainIter(n) {
  return function(f) {
    return function(x) {
      let ret = x;
      for (let i = 0; i < n; i += 1){
        ret = f(ret);
      }
      return ret;
    }
  }
}

