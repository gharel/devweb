// https://javascript.info/call-apply-decorators

function spy(func) {
  function wrapper(...args) {
    wrapper.calls.push(args);
    return func(...args);
  }

  wrapper.calls = [];
  return wrapper;
}

const adder_decorated = spy((a, b) => a + b);

console.log(adder_decorated(2, 3));
console.log(adder_decorated(3, 4));
console.log(adder_decorated.calls)

