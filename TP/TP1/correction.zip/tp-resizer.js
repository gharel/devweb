"use strict";

function resizeKO(_evt) {
  const $content = document.getElementById("content");
  const size = document.getElementById("size-selector").value;
  $content.style.fontSize = `${size}pt`;
}

function resizeOK(size) {
  return function (_evt) {
    const $content = document.getElementById("content");
    $content.style.fontSize = `${size}pt`;
  };
}

function addResizer(_evt) {
  const $btn = document.createElement("button");
  const $resizerBtns = document.getElementById("resizer-btns");
  const size = document.getElementById("size-selector").value;

  $btn.innerText = `Taille ${size}`;
  $btn.addEventListener("click", resizeOK(size));
  $resizerBtns.appendChild($btn);
}

const $addResizerBtn = document.getElementById("add-resizer");
$addResizerBtn.addEventListener("click", addResizer);

