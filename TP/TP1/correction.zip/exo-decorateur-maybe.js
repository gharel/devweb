/* eslint-disable no-unused-vars */
// solution de base
function maybeFunction(f, v) {
  return function (x) {
    const res = f(x);
    // pour éviter de calculer 2 fois f(x)
    if (res === undefined) {
      return v;
    } else {
      return res;
    }
  };
}

// avec une flèche et une if expression, mais on calcule 2 fois f(x)
const maybeArrow = (f, v) => (x) => f(x) === undefined ? v : f(x);

// une version **impure** (non fonctionnelle) où on utilise le fait qu'
// une affectation (x = v) a pour valeur celle de l'expression 'v'
// par exemple, console.log(x = 2) affiche 2
const maybeImpure = (f, v) => (x) => (res = f(x)) === undefined ? v : res;

// avec une closure supplémentaire, comme dans l'exercice précédent une
// IIFE qui va calculer f(x) UNE SEULE fois car la variable x est
// **remplacée** à 2 endroits par la valeur calculée une seule fois
const maybeArrowOnce = (f, v) => (x) => ((r) => (r === undefined ? v : r))(f(x));

// Notons qu'on peut gérer le cas d'une fonction f variadique avec les
// rest paramaters et le spread operator :
// rest parameters permet de transformer des paramètres en Array
//    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/rest_parameters
// le spread operator fait le contraire
//    https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Spread_syntax
function maybeFunctionManyArgs(f, v) {
  return function (...x) {
    const res = f(...x);
    if (res === undefined) {
      return v;
    } else {
      return res;
    }
  };
}

// version avec des flèches, rest/spred opérators et IIFE
const maybeArrowManyArgs =
  (f, v) =>
  (...x) =>
    ((r) => (r === undefined ? v : r))(f(...x));
