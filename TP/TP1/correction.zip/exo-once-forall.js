// variante où once est commun à toutes les fonctions,
// qui encapsule une version fautive avec des globaux

function createOnceForAll() {
  let executed = false;
  let res = undefined;

  function onceForAll(fct) {
    return function (...args) {
      if (!executed) {
        executed = true;
        res = fct(...args);
      }
      return res;
    };
  }
  return onceForAll;
}

const onceForAll = createOnceForAll();

const fForAll = onceForAll((x) => x);
const gForAll = onceForAll((x) => x + 2);

console.log(fForAll(1));
console.log(fForAll(2));
console.log(gForAll(1));
console.log(gForAll(2));

