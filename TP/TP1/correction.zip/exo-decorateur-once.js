/* eslint-disable no-unused-vars */
// solution de base
function onceMonadic(f) {
  let has_run = false;
  // ce booléen est là pour gérer le cas où f renvoie undefined
  let previous = undefined;
  return function(x) {
    if (!has_run) {
      has_run = true;
      previous = f(x);
    }
    return previous;
  };
}

// En version variadique avec rest/spread
function onceVariadic(f) {
  let has_run = false;
  let previous = undefined;
  return function(...x) {
    if (!has_run) {
      has_run = true;
      previous = f(...x);
    }
    return previous;
  };
}
